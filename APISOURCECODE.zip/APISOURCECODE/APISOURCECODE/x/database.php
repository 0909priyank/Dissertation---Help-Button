<?php
$servername = "148.72.232.169";
$username = "mayankmax_x";
$password = 'Falv8!26';
$dbname = "mayankmax_x";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>