<?php
include '../functions.php';
include '../database.php';
$response = array();
$data = array();
//$rawData = file_get_contents("php://input");
//
//// this returns null if not valid json
//echo json_decode($rawData);
//exit();
//$_REQUEST=json_decode($_REQUEST);
$_REQUEST = file_get_contents("php://input");
$_REQUEST= json_decode($_REQUEST,true);
$response['input'] =$_REQUEST;
$userid = isset($_REQUEST['userid']) ? trim($_REQUEST['userid']) : '';
$eventsummarydetailid = isset($_REQUEST['eventsummarydetailid']) ? trim($_REQUEST['eventsummarydetailid']) : '';
$latitude = isset($_REQUEST['latitude']) ? trim($_REQUEST['latitude']) : '';
$longitude= isset($_REQUEST['longitude']) ? trim($_REQUEST['longitude']) : '';
$address= isset($_REQUEST['address']) ? trim($_REQUEST['address']) : '';
if(strlen($eventsummarydetailid)==0){

    $response['message'] = "eventsummarydetailid missing";

//    exit();
}elseif(strlen($userid)==0){

    $response['message'] = "userid missing";

//    exit();
}elseif(strlen($latitude)==0){

    $response['message'] = "latitude missing";

//    exit();
}elseif(strlen($longitude)==0){

    $response['message'] = "longitude  missing";

//    exit();
}elseif(strlen($address)==0){

    $response['message'] = "address missing";

//    exit();
}else {
    $Apis = new Apis($conn);
    $data = $Apis->rejectAlertRequest( $eventsummarydetailid,$latitude,$longitude,$address,$userid);
    if($data){
        if($data==1){
           
            $response['success'] = "1";
            $response['data'] = $data;
            $response['message'] = "Details Fetched successfully.";
            echo json_encode(array("CommandResult" => $response));
            exit();
        }else if($data==-1){
            $response['success'] = "0";
            $response['data'] = [];
            $response['message'] = "This request is already accepted.";
            echo json_encode(array("CommandResult" => $response));
            exit();
        }

    }else{
        $response['success'] = "0";
        $response['data'] = [];
        $response['message'] = "server error";
        echo json_encode(array("CommandResult" => $response));
        exit();
    }

}
if($response['message']){
    $response['success'] = "0";
    $response['data'] = $data;
    echo json_encode(array("CommandResult" => $response));
    exit();
}