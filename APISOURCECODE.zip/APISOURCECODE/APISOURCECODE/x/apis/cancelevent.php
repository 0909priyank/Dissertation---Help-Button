<?php
include '../functions.php';
include '../database.php';
$response = array();
$data = array();
//$rawData = file_get_contents("php://input");
//
//// this returns null if not valid json
//echo json_decode($rawData);
//exit();
$_REQUEST = file_get_contents("php://input");
$_REQUEST= json_decode($_REQUEST,true);
$response['input'] = $_REQUEST;
$userid = isset($_REQUEST['userid']) ? trim($_REQUEST['userid']) : '';
$latitude = isset($_REQUEST['latitude']) ? trim($_REQUEST['latitude']) : '';
$longitude= isset($_REQUEST['longitude']) ? trim($_REQUEST['longitude']) : '';
$address= isset($_REQUEST['address']) ? trim($_REQUEST['address']) : '';
$device_type = isset($_REQUEST['device_type']) ? $_REQUEST['device_type'] : '';
$device_token = isset($_REQUEST['device_token']) ? $_REQUEST['device_token'] : '';
if(strlen($userid)==0){

    $response['message'] = "userid missing";

//    exit();
}else {
    $Apis = new Apis($conn);
    $data = $Apis->cancelEvent($userid);
	 $response['success'] = "1";
            $response['data'] = $data;
            $response['message'] = "Details Fetched successfully.";
            echo json_encode(array("CommandResult" => $response));
            exit();
    if($data){
      
           
            $response['success'] = "1";
            $response['data'] = $data;
            $response['message'] = "Details Fetched successfully.";
            echo json_encode(array("CommandResult" => $response));
            exit();
       
    }else{
        $response['success'] = "0";
        $response['data'] = [];
        $response['message'] = "Server Error";
        echo json_encode(array("CommandResult" => $response));
        exit();
    }

}
if($response['message']){
    $response['success'] = "0";
    $response['data'] = $data;
    echo json_encode(array("CommandResult" => $response));
    exit();
}