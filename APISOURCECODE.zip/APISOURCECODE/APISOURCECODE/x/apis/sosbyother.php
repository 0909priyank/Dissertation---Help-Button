<?php
include '../functions.php';
include '../database.php';
$response = array();
$data = array();
//$rawData = file_get_contents("php://input");
//
//// this returns null if not valid json
//echo json_decode($rawData);
//exit();
//$_REQUEST=json_decode($_REQUEST);
$_REQUEST = file_get_contents("php://input");
$_REQUEST= json_decode($_REQUEST,true);
$response['input'] =$_REQUEST;
$userid = isset($_REQUEST['userid']) ? trim($_REQUEST['userid']) : '';

if(strlen($userid)==0){

    $response['message'] = "userid missing";

//    exit();
}else {
    $Apis = new Apis($conn);
    $data = $Apis->sosByOther($userid);
    
       
           
            $response['success'] = "1";
            $response['data'] = $data;
            $response['message'] = "Details Fetched successfully.";
            echo json_encode(array("CommandResult" => $response));
            exit();
       

  

}
if($response['message']){
    $response['success'] = "0";
    $response['data'] = $data;
    echo json_encode(array("CommandResult" => $response));
    exit();
}