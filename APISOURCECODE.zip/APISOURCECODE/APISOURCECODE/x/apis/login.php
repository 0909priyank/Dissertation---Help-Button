<?php
include '../functions.php';
include '../database.php';
$response = array();
$data = array();
//$rawData = file_get_contents("php://input");
//
//// this returns null if not valid json
//echo json_decode($rawData);
//exit();
//$_REQUEST=json_decode($_REQUEST);
$_REQUEST = file_get_contents("php://input");
$_REQUEST= json_decode($_REQUEST,true);
$response['input'] =$_REQUEST;
$password = isset($_REQUEST['password']) ? trim($_REQUEST['password']) : '';
$email = isset($_REQUEST['mobile']) ? trim($_REQUEST['mobile']) : '';
$device_type = isset($_REQUEST['device_type']) ? $_REQUEST['device_type'] : '';
$device_token = isset($_REQUEST['device_token']) ? $_REQUEST['device_token'] : '';
if(strlen($email)==0){

    $response['message'] = "mobile missing";

//    exit();
}elseif(strlen($password)==0){

    $response['message'] = "password missing";

//    exit();
}else {
    $Apis = new Apis($conn);
    $data = $Apis->getUserData($email, $password);
    if($data){
        if($data['IsActive']==1){
           
            $response['success'] = "1";
            $response['data'] = $data;
            $response['message'] = "Details Fetched successfully.";
            echo json_encode(array("CommandResult" => $response));
            exit();
        }else{
            $response['success'] = "0";
            $response['data'] = [];
            $response['message'] = "Account has been deactivated by admin, please contact helpdesk";
            echo json_encode(array("CommandResult" => $response));
            exit();
        }

    }else{
        $response['success'] = "0";
        $response['data'] = [];
        $response['message'] = "User credentials mismatched";
        echo json_encode(array("CommandResult" => $response));
        exit();
    }

}
if($response['message']){
    $response['success'] = "0";
    $response['data'] = $data;
    echo json_encode(array("CommandResult" => $response));
    exit();
}