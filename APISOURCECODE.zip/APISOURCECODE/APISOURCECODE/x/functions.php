<?php 

class Apis { 
   
//    public $aMemberVar = 'aMemberVar Member Variable'; 
 //   public $aFuncName = 'aMemberFunc'; 
     private $conn;
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
  function userSignUp($email, $password,$mobile,$countrycode,$firstname,$lastname,$devicetoken){
       $sql = "SELECT id, firstname,Lastname,IsActive,Mobile,Email FROM users where  IsDeleted=0 and Email='".$email."'";
 
$result = $this->conn->query($sql);
 
if ($result->num_rows > 0) {
    // email already exist
    return -1;
}
  $sql = "SELECT id, firstname,Lastname,IsActive,Mobile,Email FROM users where  IsDeleted=0 and Mobile='".$mobile."'";
 
$result = $this->conn->query($sql);
	
if ($result->num_rows > 0) {
    // mobile already exist
    return -2;
}
 $date = date('Y-m-d h:i:s', time());
	//  print_r($date);die;
$sql = "INSERT INTO `users` (`id`, `Firstname`, `Lastname`, `Countrycode`, `Mobile`, `Email`, `Password`, `IsActive`, `IsDeleted`, `IsApproved`, `CreatedOn`,`device_token`) VALUES (NULL, '".$firstname."', '".$lastname."', '".$countrycode."', '".$mobile."', '".$email."','".md5($password)."', '1', '0', '0', '".$date."','".$devicetoken."')";
//echo $sql ;die;
if ($this->conn->query($sql) === TRUE) {
    return $this->getUserData($mobile, $password);
} else {
    // server error
   return -3;
}    
}


function getUserData($mobile, $password){
    try{
    
    $sql = "SELECT id, firstname,Lastname,IsActive,Mobile,Email FROM users where  IsDeleted=0 and Mobile='".$mobile."' and Password='".md5($password)."'";
  //print_r($sql);die;
$result = $this->conn->query($sql);
//print_r($result);die;
$data=[];
if ($result->num_rows > 0) {
    // output data of each row
  
  
   
     return $result->fetch_assoc();
} else {
     return $data;
    //echo "0 results";
}
$conn->close();

}
catch(Exception $e){
    echo "Error: " . $e->getMessage();
}
}
function setUserLocation($userid,$latitude, $longitude,$address){
     try{
    
    $sql = "SELECT * FROM `userLocations` WHERE UserId=".$userid;
 
$result = $this->conn->query($sql);
		 $data=[];
		 $data['is_sos']=0;
               $data['EventSummaryDetailId']=0;
		 $data['other_userid']=0;	
$temp=$result->fetch_assoc();
		
if ($result->num_rows > 0) {
	  if($temp['EventSummaryDetailId']>0)
		   $data['EventSummaryDetailId']=$temp['EventSummaryDetailId'];
    // output data of each row
   $date = date('Y-m-d h:i:s', time());
     $sql = "UPDATE `userLocations` SET Latitude='".$latitude."',Longitude='".$longitude."',Address='".$address."' ,modified_on= '".$date."' where UserId='".$userid."'";
    // print_r($sql);die;
     $result = $this->conn->query($sql);
    // return $data;
} else {
	$date = date('Y-m-d h:i:s', time());
     $sql = "INSERT INTO `userLocations` (`Id`, `UserId`, `Latitude`, `Longitude`, `EventSummaryDetailId`, `Address`, `CreatedOn`,modified_on) VALUES (NULL, '".$userid."', '".$latitude."', '".$longitude."', '', '".$address."', '".$date."', '".$date."')";
     $result = $this->conn->query($sql);
   //  return $data;
    //echo "0 results";
}
//return $data;
$sql="select * from eventSummary where UserId=$userid and isopenjob=1";
 $result = $this->conn->query($sql);
if ($result->num_rows > 0)
 $data['is_sos']=1;
$sql="select * from eventSummaryDetail where OtherUserId=$userid and IsAlertAccept=1";
 $result = $this->conn->query($sql);
if ($result->num_rows > 0)
 $data['other_userid']=1;		 
return $data;
$conn->close();


}
catch(Exception $e){
    echo "Error: " . $e->getMessage();
}
}
function setEventSummary($userid, $eventypeid,$latitude,$longitude,$address){
	   $date = date('Y-m-d h:i:s', time());
       $sql = "INSERT INTO `eventSummary` (`Id`, `UserId`, `EventTypeId`, `Latitude`, `Longitude`, `Address`, `CreatedOn`) VALUES (NULL, '".$userid."', '".$eventypeid."', '".$latitude."', '".$longitude."', '".$address."', '".$date."')";
	   
       $result = $this->conn->query($sql);
       if ($result) {
           $esid=$this->conn->insert_id;
           $this->fetchpushusers($userid,$esid);
           
           return 1;
       }else{
           return -1;
       }
   
}
function fetchpushusers($userid,$esid){
        $sql="
SELECT a.UserId AS from_id, b.UserId AS to_id, u.device_token,u.Firstname,u.Lastname,u.Mobile,
   111.111 *
    DEGREES(ACOS(COS(RADIANS(a.Latitude))
         * COS(RADIANS(b.Latitude))
         * COS(RADIANS(a.Longitude - b.Longitude))
         + SIN(RADIANS(a.Latitude))
         * SIN(RADIANS(b.Latitude)))) AS distance_in_km
  FROM userLocations AS a
  JOIN userLocations AS b on b.UserId!=$userid
  inner join users u on   u.id=b.UserId and u.IsActive=1 and u.IsDeleted=0
 WHERE a.UserId = $userid and (111.111 *
    DEGREES(ACOS(COS(RADIANS(a.Latitude))
         * COS(RADIANS(b.Latitude))
         * COS(RADIANS(a.Longitude - b.Longitude))
         + SIN(RADIANS(a.Latitude))
         * SIN(RADIANS(b.Latitude)))))<2";
  $result = $this->conn->query($sql);
	
           if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $this->sendpush($row,$esid);
    }
    
           
} 

}
function getUsers($userid){
        $sql="
SELECT distinct b.UserId AS other_user_id, b.Latitude,b.Longitude,b.Address,a.EventSummaryDetailId,u.Firstname,u.Lastname,u.Mobile,
   111.111 *
    DEGREES(ACOS(COS(RADIANS(a.Latitude))
         * COS(RADIANS(b.Latitude))
         * COS(RADIANS(a.Longitude - b.Longitude))
         + SIN(RADIANS(a.Latitude))
         * SIN(RADIANS(b.Latitude)))) AS distance_in_km
  FROM userLocations AS a
  JOIN userLocations AS b on b.UserId!=$userid
  inner join users u on   u.id=b.UserId and u.IsActive=1 and u.IsDeleted=0
  left join eventSummary ev on ev.UserId=$userid
 WHERE a.UserId = $userid and (111.111 *
    DEGREES(ACOS(COS(RADIANS(a.Latitude))
         * COS(RADIANS(b.Latitude))
         * COS(RADIANS(a.Longitude - b.Longitude))
         + SIN(RADIANS(a.Latitude))
         * SIN(RADIANS(b.Latitude)))))<2";
  $result = $this->conn->query($sql);
	
           if ($result->num_rows > 0) {
    // output data of each row
			   $rows=[];
    while($row = $result->fetch_assoc()) {
       $rows[]=$row;        
    }
    
     return $rows;      
} 
  return [];
}	
function sendpush($row,$esid){
  
// $device_token, $msg_type, $name, $title,$msg,$senderid,$image
        $ouid=$row['to_id'];
        $senderid=$row['from_id'];
        $msg_type="alert";
        $msg="Someone need your help";
        $title="";
        $device_token=$row['device_token'];
        $url = 'https://fcm.googleapis.com/fcm/send';
	    $registrationIDs = array($device_token);
//        $key = "AAAAlxi7N_k:APA91bFKl-9wwp_C63Bz45vwVJQ8mq6si726Gt4hBqg3lJAgUhRIHhr7FzKbY0nEdEt_h9so6WnuUSeWltliYZisEXjWTZFR6zb-US-m4kYWipwxRh5Uhhrw8XcEASLJwsNi1mq6Af6X";
        $key = "AAAAYgDqH8A:APA91bGJNl5RcsasQlGq75A0qLleY6tBQIdqpxo-lqM8IiQypGbdF_3gJQGnF2Mzi24LuY2xyJODN_xbJGEPDXuDTpEf3P6JI4eg-jTkYh8xNCmpmB0y3iGlFG1dtrsfEZUZLPiUjlWnCMD61VcecWIEtJyimhUyvA";
        $message =(object)  array("eventsummaryid" => $esid, "msg_type" => $msg_type , "msg" => $msg, "title"=>$title,'senderid'=>$senderid);
        $headers = array(
            'Authorization: key='.$key,
            'Content-Type: application/json'
        );


        $fields = array(
            'registration_ids' => $registrationIDs,
            'data' => $message,
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
	// print_r($result);die;
	    $result=1;
        if (curl_errno($ch)) {
            echo 'Curl error: ' . curl_error($ch);
        }
        curl_close($ch);
        if($result){
			$date = date('Y-m-d h:i:s', time());
            $sql="INSERT INTO `eventSummaryDetail` (`Id`, `EventSummaryId`, `OtherUserId`, `IsAlertSent`, `IsAlertAccept`, `IsALertCancel`, `IsEventComplete`, `IsCompleteLatitude`, `IsCompleteLongitude`, `IsCompleteAddress`, `CompletedOn`, `CreatedOn`) VALUES (NULL, '".$esid."', '".$ouid."', 1, NULL, NULL, NULL, '', '', '', NULL, '".$date."')";
            $this->conn->query($sql);
        }


        return $result;
    

    
}
function acceptAlertRequest( $eventsummarydetailid,$latitude,$longitude,$address,$userid){
    $sql="SELECT * FROM eventSummaryDetail esd WHERE esd.IsAlertAccept=1 and esd.Id=$eventsummarydetailid";
    $result=$this->conn->query($sql);
	
      if ($result->num_rows > 0) {
          return -1;
      }else{
		  $sql="select * from eventSummaryDetail esd 
		  inner join eventSummary es on es.id=esd.EventSummaryId where esd.Id=$eventsummarydetailid
		  ";
		   $result=$this->conn->query($sql);	
		  $row = $result->fetch_assoc();
                  $sosuserid=$row['UserId'];
		 
          $sql="UPDATE `eventSummaryDetail` set `IsAlertAccept`=1,`IsCompleteLatitude`='".$latitude."',
		  `IsCompleteLongitude`='".$longitude."',
		  `IsCompleteAddress`='".$address."' 
		  WHERE Id=$eventsummarydetailid 
		  and OtherUserId=$userid";
          $result=$this->conn->query($sql);
           $sql="update userLocations set EventSummaryDetailId=$eventsummarydetailid where UserId=$sosuserid";
            $result=$this->conn->query($sql);
		 
           if ($result) {
               return 1;
           }else{
               return 0;
           }
           
      }
}
function rejectAlertRequest( $eventsummarydetailid,$latitude,$longitude,$address,$userid){
    
          $sql="UPDATE `eventSummaryDetail` set  `IsALertCancel`=1,`IsCompleteLatitude`='".$latitude."',`IsCompleteLongitude`='".$longitude."',`IsCompleteAddress`='".$address."' WHERE Id=$eventsummarydetailid and OtherUserId=$userid";
          $result=$this->conn->query($sql);
           if ($result) {
               return 1;
           }else{
               return 0;
           }
   
} 
function isCompleteAlertRequest( $eventsummarydetailid,$latitude,$longitude,$address,$userid){
	

	if($userid){
		 $sql="UPDATE `eventSummaryDetail` set `IsCompleteLatitude`='".$latitude."',`IsCompleteLongitude`='".$longitude."',`IsCompleteAddress`='".$address."' WHERE IsAlertAccept and OtherUserId=$userid";
          $result=$this->conn->query($sql);
           if ($result) {
			   $res=$this->checkIsComplete(0,$userid);
			 
               return $res;
           }else{
               return [];
           }
		
	}else{
		  $res=$this->checkIsComplete($eventsummarydetailid,$userid);
			 
               return $res;
	}	  
    
}
	function checkIsComplete($evid,$userid){
		if($evid){
			$sql="select es.UserId,esd.OtherUserId from eventSummaryDetail esd 
inner join eventSummary es on es.id=esd.EventSummaryId
where esd.id=$evid";
			$result=$this->conn->query($sql);	
		  $r = $result->fetch_assoc();
                  $userid=$r['UserId'];
			      $otheruserid=$r['OtherUserId'];
			$sql="SELECT a.UserId,a.latitude,a.longitude,a.address,
   111.111 *
    DEGREES(ACOS(COS(RADIANS(a.Latitude))
         * COS(RADIANS(b.Latitude))
         * COS(RADIANS(a.Longitude - b.Longitude))
         + SIN(RADIANS(a.Latitude))
         * SIN(RADIANS(b.Latitude)))) AS distance_in_km
  FROM userLocations AS a
  join userLocations as b on b.UserId=$userid
  where a.UserId=$otheruserid
  ";  
			 $result=$this->conn->query($sql);
		if ($result->num_rows > 0) {
			$row=$result->fetch_assoc();
			$row['is_complete']=0;
			if(($row['distance_in_km']*1000)<20){
				$date = date('Y-m-d h:i:s', time());
                                  
                                  $sql="update userLocations set EventSummaryDetailId=0 where UserId=$userid";
            $result=$this->conn->query($sql);
                                  $sql="update eventSummary set isopenjob=0 where UserId=$userid";
            $result=$this->conn->query($sql);
				 $sql="UPDATE `eventSummaryDetail` set `IsEventComplete`=1,`CompletedOn`='".$date."' WHERE Id=$evid ";

				if($this->conn->query($sql)){
					$row['is_complete']=1;
				}         				
			}
			return $row;
			
		}
			return [];
			
			// end $evid if	
		}else{
			//print_r("hello");die;
			$sql="select esd.id,es.UserId,esd.OtherUserId from eventSummaryDetail esd 
inner join eventSummary es on es.id=esd.EventSummaryId
where esd.OtherUserId=$userid and IsAlertAccept=1";
			$result=$this->conn->query($sql);	
		  $r = $result->fetch_assoc();
                  $userid=$r['UserId'];
			      $otheruserid=$r['OtherUserId'];
			 $evid=$r['id'];
			$sql="SELECT a.UserId,a.latitude,a.longitude,a.address,
   111.111 *
    DEGREES(ACOS(COS(RADIANS(a.Latitude))
         * COS(RADIANS(b.Latitude))
         * COS(RADIANS(a.Longitude - b.Longitude))
         + SIN(RADIANS(a.Latitude))
         * SIN(RADIANS(b.Latitude)))) AS distance_in_km
  FROM userLocations AS a
  join userLocations as b on b.UserId=$otheruserid
  where a.UserId=$userid
  ";  
			 $result=$this->conn->query($sql);
		if ($result->num_rows > 0) {
			$row=$result->fetch_assoc();
			$row['is_complete']=0;
			if(($row['distance_in_km']*1000)<20){
				$date = date('Y-m-d h:i:s', time());
                                  
                                  $sql="update userLocations set EventSummaryDetailId=0 where UserId=$userid";
            $result=$this->conn->query($sql);
                                  $sql="update eventSummary set isopenjob=0 where UserId=$userid";
            $result=$this->conn->query($sql);
				 $sql="UPDATE `eventSummaryDetail` set `IsEventComplete`=1,`CompletedOn`='".$date."' WHERE Id=$evid ";

				if($this->conn->query($sql)){
					$row['is_complete']=1;
				}         				
			}
			return $row;
			
		}
			return [];
			
			// end else
		}
		 
		
$conn->close();
		
	}	
	function sosByMe($uid){
		$sql="SELECT u.id,u.Firstname,u.Lastname,u.Mobile,et.Name as event,evd.IsAlertAccept,evd.IsALertCancel,es.CreatedOn FROM eventSummary es

join eventTypes et on et.id=es.EventTypeId
left join eventSummaryDetail evd on es.Id=evd.EventSummaryId
join users u on u.id=evd.OtherUserId
WHERE es.UserId=$uid
AND evd.IsAlertAccept= 1
AND evd.IsEventComplete<> 1";
		 $result=$this->conn->query($sql);
		if ($result->num_rows > 0) {
			$rows=[];
			while($row=$result->fetch_assoc()){
				$rows[]=$row;
			}
			return $rows;
			
		}else{
			return [];
		}
	}
	function sosByOther($uid){
		$sql="SELECT esd.id as eventsummarydetailid,u.id,u.Firstname,u.Lastname,et.Name as event,esd.CreatedOn FROM eventSummaryDetail esd
join eventSummary es on es.id=esd.EventSummaryId
join users u on u.id=es.UserId
join eventTypes et on et.id=es.EventTypeId
WHERE esd.OtherUserId=$uid
AND (IsAlertAccept=0 OR IsAlertAccept IS NULL)";
	 
		 $result=$this->conn->query($sql);
		if ($result->num_rows > 0) {
			$rows=[];
			while($row=$result->fetch_assoc()){
				$rows[]=$row;
			}
		return $rows;
			
		}else{
			return [];
		}
	}
	function getIsSafeArea($userid,$latitude, $longitude){
		
		   $sql="SELECT EventTypeId,et.Name,count(EventTypeId) as count from eventSummary ev inner join eventTypes et on et.id=EventTypeId
 WHERE  (111.111 *
    DEGREES(ACOS(COS(RADIANS(ev.Latitude))
         * COS(RADIANS($latitude))
         * COS(RADIANS(ev.Longitude - $longitude))
         + SIN(RADIANS(ev.Latitude))
         * SIN(RADIANS($latitude)))))<1 group by ev.EventTypeId";
  $result = $this->conn->query($sql);
		//print_r($sql);die;
	  $rows=[];
           if ($result->num_rows > 0) {
    // output data of each row
			   $rows=[];
    while($row = $result->fetch_assoc()) {
       $rows[]=$row;        
    }
    
     
	}
		return $rows;   
	}
	function cancelEvent($userid){
		
		   $sql="SELECT * 
 from eventSummary ev 
 WHERE  ev.UserId=$userid";
  $result = $this->conn->query($sql);
	
           if ($result->num_rows > 0) {
    // output data of each row
			
			   $row = $result->fetch_assoc();
			   $id=$row['Id'];
			      $sql="update eventSummary set isopenjob=2 where id=$id";
            $result=$this->conn->query($sql);
             
    
              //return $result;   
		   }else{
			   $sql="SELECT * 
 from eventSummary ev 
 WHERE  ev.UserId=$userid";
			   $result = $this->conn->query($sql);
			    if ($result->num_rows > 0) {
    // output data of each row
			   
			   $row = $result->fetch_assoc();
				  $id=$row['Id'];	
              $sql="update eventSummary set isopenjob=2 where id=$id";
            $result=$this->conn->query($sql);
             
    
           //   return $result; 
		   }
			   
		   }
		$sql="update userLocations set    EventSummaryDetailId=0 where 
		UserId=$userid";
		$this->conn->query($sql);
		return $result;
		
	}
	
// end class
}
?>
